/* E1M1 CE experiment, GPL-2.0-or-later.
 * This is a compact new sector renderer using the original Doom BSP/seg data.
 * Near-first BSP traversal follows id Software's R_RenderBSPNode algorithm;
 * this is not yet a port of Doom's complete renderer or game simulation.
 */
#include "engine.h"
#include "generated.h"
#include <limits.h>
#include <stdlib.h>
#include <string.h>

_Static_assert(sizeof(Vertex)==4,"Vertex disk layout");
_Static_assert(sizeof(Line)==14,"Line disk layout");
_Static_assert(sizeof(Side)==8,"Side disk layout");
_Static_assert(sizeof(Sector)==10,"Sector disk layout");
_Static_assert(sizeof(Seg)==14,"Seg disk layout");
_Static_assert(sizeof(Subsector)==4,"Subsector disk layout");
_Static_assert(sizeof(Node)==28,"Node disk layout");
_Static_assert(sizeof(MapActor)==14,"Actor disk layout");

#define FOCAL 64
#define CENTER 40
#define NEAR_Z 4
#define ABS(a) ((a)<0?-(a):(a))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))
#define CLAMP(a,l,h) MIN(MAX(a,l),h)

Player player;
RenderStats render_stats;
View engine_view;
const Vertex *map_vertices;
const Line *map_lines;
const Sector *map_sectors;
const uint8_t *map_palette;
static const Side *sides;
static const Seg *segs;
static const Subsector *subsectors;
static const Node *nodes;
static const MapActor *map_actors;
static const int16_t *blockmap;
static const uint8_t *colormaps;
static const uint8_t *images[NUM_TILES];

/* Only mutable data lives in RAM. Level and images stay in archived AppVars. */
static int16_t sector_ceiling[NUM_SECTORS],sector_target[NUM_SECTORS];
static int16_t sector_floor[NUM_SECTORS],floor_target[NUM_SECTORS];
static uint8_t floor_wait[NUM_SECTORS];
static uint8_t depthbuffer[VIEW_W*VIEW_H],planes[VIEW_W*VIEW_H];
static uint8_t cliptop[VIEW_W],clipbottom[VIEW_W];
static int16_t vertex_side[NUM_VERTICES],vertex_depth[NUM_VERTICES];
static uint8_t vertex_stamp[NUM_VERTICES],frame_stamp;
static int camx,camy,camcos,camsin;
static uint8_t use_held;
static uint16_t random_state;

typedef struct { int16_t x,y; uint8_t sector,hp,removed,cooldown; } Actor;
static Actor actors[NUM_ACTORS];
static uint8_t sprite_order[NUM_ACTORS];
static int16_t sprite_z[NUM_ACTORS],sprite_x[NUM_ACTORS];

static int isin(unsigned a) { return sine_table[a&1023]; }
static int icos(unsigned a) { return sine_table[(a+256)&1023]; }
static unsigned rnd(void) { random_state=(uint16_t)(random_state*25173u+13849u); return random_state; }

/* Doom node child 0 is the right-hand side of its partition. Avoid native
 * int multiplication here: differences/products can exceed 24-bit range. */
static unsigned node_side(int x,int y,const Node *n) {
    if (!n->dx) return x<=n->x ? n->dy>0 : n->dy<0;
    if (!n->dy) return y<=n->y ? n->dx<0 : n->dx>0;
    int32_t left=(int32_t)(x-n->x)*n->dy;
    int32_t right=(int32_t)(y-n->y)*n->dx;
    return right>=left;
}

uint8_t engine_sector(int x,int y) {
    unsigned index=NUM_NODES-1;
    while (!(index&0x8000u)) {
        const Node *n=&nodes[index];
        index=n->child[node_side(x,y,n)];
    }
    const Subsector *sub=&subsectors[index&0x7fffu];
    const Seg *seg=&segs[sub->first];
    return sides[map_lines[seg->line].side[seg->side]].sector;
}

bool engine_init(const uint8_t *map,unsigned size,const uint8_t *const *banks,const unsigned *sizes) {
    if (size!=MAP_SIZE || memcmp(map,"D84MAP01",8) || memcmp(map+8,asset_id,8)) return false;
    for (unsigned i=0;i<NUM_BANKS;++i)
        if (sizes[i]!=bank_sizes[i] || memcmp(banks[i],"D84TEX01",8) || memcmp(banks[i]+8,asset_id,8)) return false;
    map_vertices=(const Vertex *)(map+OFF_VERTICES);
    map_lines=(const Line *)(map+OFF_LINES);
    sides=(const Side *)(map+OFF_SIDES);
    map_sectors=(const Sector *)(map+OFF_SECTORS);
    segs=(const Seg *)(map+OFF_SEGS);
    subsectors=(const Subsector *)(map+OFF_SUBSECTORS);
    nodes=(const Node *)(map+OFF_NODES);
    map_actors=(const MapActor *)(map+OFF_ACTORS);
    blockmap=(const int16_t *)(map+OFF_BLOCKMAP);
    map_palette=map+OFF_PALETTE;
    colormaps=map+OFF_COLORMAP;
    for (unsigned i=0;i<NUM_TILES;++i) images[i]=banks[tile_bank[i]]+tile_offset[i];
    engine_view.width=VIEW_W;engine_view.height=VIEW_H;
    engine_reset();
    return true;
}

void engine_reset(void) {
    memset(&player,0,sizeof(player));
    player.x=(int32_t)START_X*256;
    player.y=(int32_t)START_Y*256;
    player.angle=START_ANGLE;
    player.health=100;
    player.ammo=50;
    player.texture_planes=true;
    player.sector=engine_sector(START_X,START_Y);
    player.floor=map_sectors[player.sector].floor;
    player.eye=player.floor+41;
    random_state=1;
    use_held=0;
    memset(floor_wait,0,sizeof(floor_wait));
    for (unsigned i=0;i<NUM_SECTORS;++i) {
        sector_target[i]=sector_ceiling[i]=map_sectors[i].ceiling;
        floor_target[i]=sector_floor[i]=map_sectors[i].floor;
    }
    for (unsigned i=0;i<NUM_ACTORS;++i) {
        const MapActor *m=&map_actors[i];
        actors[i]=(Actor){m->x,m->y,engine_sector(m->x,m->y),m->hp,0,0};
        if (m->kind==1) ++player.total;
    }
}

static bool line_passable(const Line *l,int floor) {
    if (l->side[1]==65535u || (l->flags&1)) return false;
    unsigned a=sides[l->side[0]].sector,b=sides[l->side[1]].sector;
    int bottom=MAX(sector_floor[a],sector_floor[b]);
    return bottom-floor<=24 && MIN(sector_ceiling[a],sector_ceiling[b])-MAX(bottom,floor)>=56;
}

static bool collision_line(unsigned i,int x,int y,int floor) {
    const int radius=16;
        const Line *l=&map_lines[i];
        const Vertex *a=&map_vertices[l->v1],*b=&map_vertices[l->v2];
        if (x<MIN(a->x,b->x)-radius || x>MAX(a->x,b->x)+radius || y<MIN(a->y,b->y)-radius || y>MAX(a->y,b->y)+radius) return true;
        if (line_passable(l,floor)) return true;
        int dx=b->x-a->x,dy=b->y-a->y,px=x-a->x,py=y-a->y;
        int32_t len2=(int32_t)dx*dx+(int32_t)dy*dy;
        int32_t dot=(int32_t)px*dx+(int32_t)py*dy;
        if (dot<0) {
            if ((int32_t)px*px+(int32_t)py*py<radius*radius) return false;
        } else if (dot>len2) {
            px=x-b->x; py=y-b->y;
            if ((int32_t)px*px+(int32_t)py*py<radius*radius) return false;
        } else if (len2) {
            /* Project to 8.8 along segment. The bbox above bounds these
             * products for E1M1; use 64-bit only in this infrequent path. */
            int32_t t=(int32_t)(((int64_t)dot*256)/len2);
            px=x-(a->x+(int)((int32_t)dx*t/256));
            py=y-(a->y+(int)((int32_t)dy*t/256));
            if ((int32_t)px*px+(int32_t)py*py<radius*radius) return false;
        }
    return true;
}

bool engine_can_move(int x,int y,int floor) {
    int left=(x-16-blockmap[0])>>7,right=(x+16-blockmap[0])>>7;
    int bottom=(y-16-blockmap[1])>>7,top=(y+16-blockmap[1])>>7;
    if (left<0 || bottom<0 || right>=blockmap[2] || top>=blockmap[3]) return false;
    for (int row=bottom;row<=top;++row) for (int col=left;col<=right;++col) {
        unsigned offset=(uint16_t)blockmap[4+row*blockmap[2]+col];
        /* Each original Doom block list starts with a dummy zero. */
        for (++offset;blockmap[offset]!=-1;++offset)
            if (!collision_line((uint16_t)blockmap[offset],x,y,floor)) return false;
    }
    uint8_t s=engine_sector(x,y);
    return sector_floor[s]-floor<=24 && sector_ceiling[s]-MAX(sector_floor[s],floor)>=56;
}

/* Segment crossing test for shooting/AI. The prototype treats the shot as
 * horizontal at eye height and respects closed doors and vertical openings. */
static bool sight(int x,int y,int tx,int ty,int eye) {
    int dx=tx-x,dy=ty-y;
    for (unsigned i=0;i<NUM_LINES;++i) {
        const Line *l=&map_lines[i];
        const Vertex *a=&map_vertices[l->v1],*b=&map_vertices[l->v2];
        if (MAX(x,tx)<MIN(a->x,b->x) || MIN(x,tx)>MAX(a->x,b->x) || MAX(y,ty)<MIN(a->y,b->y) || MIN(y,ty)>MAX(a->y,b->y)) continue;
        if (l->side[1]!=65535u) {
            unsigned sa=sides[l->side[0]].sector,sb=sides[l->side[1]].sector;
            if (eye>MAX(sector_floor[sa],sector_floor[sb]) && eye<MIN(sector_ceiling[sa],sector_ceiling[sb])) continue;
        }
        int32_t c1=(int32_t)(a->x-x)*dy-(int32_t)(a->y-y)*dx;
        int32_t c2=(int32_t)(b->x-x)*dy-(int32_t)(b->y-y)*dx;
        int32_t c3=(int32_t)(x-a->x)*(b->y-a->y)-(int32_t)(y-a->y)*(b->x-a->x);
        int32_t c4=(int32_t)(tx-a->x)*(b->y-a->y)-(int32_t)(ty-a->y)*(b->x-a->x);
        if ((c1<0)!=(c2<0) && (c3<0)!=(c4<0)) return false;
    }
    return true;
}

static void activate_sector(unsigned s) {
    int ceiling=32767,floor=32767;
    for (unsigned j=0;j<NUM_LINES;++j) {
        const Line *edge=&map_lines[j];
        if (edge->side[1]==65535u) continue;
        unsigned a=sides[edge->side[0]].sector,b=sides[edge->side[1]].sector;
        if (a!=s && b!=s) continue;
        unsigned other=a==s?b:a;
        ceiling=MIN(ceiling,sector_ceiling[other]-4);
        floor=MIN(floor,sector_floor[other]);
    }
    if (ceiling!=32767) sector_target[s]=MAX(sector_ceiling[s],ceiling);
    if (floor!=32767 && floor<sector_floor[s]) floor_target[s]=floor;
}

static void cross_triggers(int oldx,int oldy,int x,int y) {
    if (oldx==x && oldy==y) return;
    for (unsigned i=0;i<NUM_WALK_TRIGGERS;++i) {
        const Line *line=&map_lines[walk_triggers[i]];
        const Vertex *a=&map_vertices[line->v1],*b=&map_vertices[line->v2];
        if (MAX(oldx,x)<MIN(a->x,b->x) || MIN(oldx,x)>MAX(a->x,b->x) || MAX(oldy,y)<MIN(a->y,b->y) || MIN(oldy,y)>MAX(a->y,b->y)) continue;
        int dx=b->x-a->x,dy=b->y-a->y;
        int32_t before=(int32_t)(oldx-a->x)*dy-(int32_t)(oldy-a->y)*dx;
        int32_t after=(int32_t)(x-a->x)*dy-(int32_t)(y-a->y)*dx;
        if ((before<0)==(after<0)) continue;
        for (unsigned s=0;s<NUM_SECTORS;++s) {
            if (!line->tag || map_sectors[s].tag!=line->tag) continue;
            int lowest=sector_floor[s];
            for (unsigned j=0;j<NUM_LINES;++j) {
                const Line *edge=&map_lines[j];
                if (edge->side[1]==65535u) continue;
                unsigned sa=sides[edge->side[0]].sector,sb=sides[edge->side[1]].sector;
                if (sa==s) lowest=MIN(lowest,sector_floor[sb]);
                if (sb==s) lowest=MIN(lowest,sector_floor[sa]);
            }
            if (line->special==36) floor_target[s]=MIN(sector_floor[s],lowest+8);
            else if (!floor_wait[s] && sector_floor[s]==map_sectors[s].floor) {
                floor_target[s]=lowest;floor_wait[s]=255;
            }
        }
    }
}

static void use(void) {
    int x=(int)(player.x/256),y=(int)(player.y/256);
    int c=icos(player.angle),s=isin(player.angle);
    int best=80; const Line *found=NULL;
    for (unsigned i=0;i<NUM_LINES;++i) {
        const Line *l=&map_lines[i];
        if (!l->special || l->special==48) continue;
        const Vertex *a=&map_vertices[l->v1],*b=&map_vertices[l->v2];
        int ax=a->x-x,ay=a->y-y,bx=b->x-x,by=b->y-y;
        int ar=(int)(((int32_t)ax*s-(int32_t)ay*c)/256);
        int br=(int)(((int32_t)bx*s-(int32_t)by*c)/256);
        if ((ar<0)==(br<0) || ar==br) continue;
        int az=(int)(((int32_t)ax*c+(int32_t)ay*s)/256);
        int bz=(int)(((int32_t)bx*c+(int32_t)by*s)/256);
        int z=az+(int)((int32_t)(bz-az)*ar/(ar-br));
        if (z>0 && z<best) { best=z;found=l; }
    }
    if (!found) return;
    if (found->special==11) {player.exited=true;return;}
    if (found->side[1]!=65535u) activate_sector(sides[found->side[1]].sector);
}

static void hurt(int damage) {
    int absorbed=MIN(player.armor,damage/3);
    player.armor-=absorbed; player.health-=damage-absorbed; player.damage=5;
    if (player.health<=0) {player.health=0;player.dead=true;}
}

static void shoot(void) {
    if (player.fire || !player.ammo) return;
    --player.ammo;player.fire=8;
    int c=icos(player.angle),s=isin(player.angle),best=2048,index=-1;
    int x=(int)(player.x/256),y=(int)(player.y/256);
    for (unsigned i=0;i<NUM_ACTORS;++i) {
        Actor *a=&actors[i];
        if (!a->hp || a->removed) continue;
        int dx=a->x-x,dy=a->y-y;
        int z=(int)(((int32_t)dx*c+(int32_t)dy*s)/256);
        int r=(int)(((int32_t)dx*s-(int32_t)dy*c)/256);
        if (z<0 || z>=best || ABS(r)>20) continue;
        if (!sight(x,y,a->x,a->y,player.eye)) continue;
        best=z;index=(int)i;
    }
    if (index>=0) {
        Actor *a=&actors[index];
        int damage=5*(1+(rnd()%3));
        if (damage>=a->hp) {
            a->hp=0;
            if (map_actors[index].kind==1) {++player.kills;player.ammo+=5;}
        } else a->hp-=damage;
    }
}

void engine_tick(uint8_t input) {
    if (player.dead || player.exited) return;
    ++player.ticks;
    if (player.fire) --player.fire;
    if (player.damage) --player.damage;
    if (!(input&INPUT_STRAFE)) {
        int turn=(input&INPUT_RUN)?12:8;
        if (input&INPUT_LEFT) player.angle=(player.angle+turn)&1023;
        if (input&INPUT_RIGHT) player.angle=(player.angle-turn)&1023;
    }
    int forward=((input&INPUT_FORWARD)!=0)-((input&INPUT_BACK)!=0);
    int strafe=(input&INPUT_STRAFE)?(((input&INPUT_RIGHT)!=0)-((input&INPUT_LEFT)!=0)):0;
    int c=icos(player.angle),s=isin(player.angle),speed=(input&INPUT_RUN)?8:4;
    int oldx=(int)(player.x/256),oldy=(int)(player.y/256);
    int32_t nx=player.x+(forward*c+strafe*s)*speed;
    int32_t ny=player.y+(forward*s-strafe*c)*speed;
    if (nx!=player.x && engine_can_move((int)(nx/256),(int)(player.y/256),player.floor)) player.x=nx;
    if (ny!=player.y && engine_can_move((int)(player.x/256),(int)(ny/256),player.floor)) player.y=ny;
    int x=(int)(player.x/256),y=(int)(player.y/256);
    player.sector=engine_sector(x,y);
    player.floor=sector_floor[player.sector];
    int target=player.floor+41;
    player.eye+=CLAMP(target-player.eye,-8,8);
    cross_triggers(oldx,oldy,x,y);
    for (unsigned i=0;i<NUM_SECTORS;++i) {
        sector_ceiling[i]+=CLAMP(sector_target[i]-sector_ceiling[i],0,2);
        sector_floor[i]+=CLAMP(floor_target[i]-sector_floor[i],-4,4);
        if (floor_wait[i]==255 && sector_floor[i]==floor_target[i]) floor_wait[i]=105;
        else if (floor_wait[i] && floor_wait[i]<255 && !--floor_wait[i]) floor_target[i]=map_sectors[i].floor;
    }
    if ((input&INPUT_USE) && !use_held) use();
    use_held=(input&INPUT_USE)!=0;
    if (input&INPUT_FIRE) shoot();
    if (!(player.ticks&31) && (map_sectors[player.sector].special==5 || map_sectors[player.sector].special==7 || map_sectors[player.sector].special==16)) hurt(5);
    for (unsigned i=0;i<NUM_ACTORS;++i) {
        Actor *a=&actors[i];const MapActor *m=&map_actors[i];
        if (a->removed) continue;
        int dx=x-a->x,dy=y-a->y,dist=MAX(ABS(dx),ABS(dy));
        if (m->kind==2 && dist<28) {
            bool take=true;
            switch (m->type) {
                case 2011:case 2012: if(player.health>=100)take=false; else player.health=MIN(100,player.health+(m->type==2011?10:25));break;
                case 2014:player.health=MIN(200,player.health+1);break;
                case 2015:player.armor=MIN(200,player.armor+1);break;
                case 2018:case 2019:player.armor=MAX(player.armor,m->type==2018?100:200);break;
                default:player.ammo=MIN(200,player.ammo+10);break;
            }
            if (take) a->removed=1;
        }
        if (m->kind!=1 || !a->hp || dist>768) continue;
        if (a->cooldown) --a->cooldown;
        if (((player.ticks+i)&7)!=0 || !sight(a->x,a->y,x,y,player.eye)) continue;
        if (dist<384 && !a->cooldown) {hurt(2+(rnd()%7));a->cooldown=35;}
        if (dist>48) {
            int mx=a->x+CLAMP(dx,-4,4),my=a->y+CLAMP(dy,-4,4);
            if (engine_can_move(mx,a->y,sector_floor[a->sector])) a->x=mx;
            if (engine_can_move(a->x,my,sector_floor[a->sector])) a->y=my;
            a->sector=engine_sector(a->x,a->y);
        }
    }
}

static void vertex(unsigned v,int *r,int *z) {
    if (vertex_stamp[v]!=frame_stamp) {
        int dx=map_vertices[v].x-camx,dy=map_vertices[v].y-camy;
        vertex_side[v]=(int16_t)(((int32_t)dx*camsin-(int32_t)dy*camcos)/256);
        vertex_depth[v]=(int16_t)(((int32_t)dx*camcos+(int32_t)dy*camsin)/256);
        vertex_stamp[v]=frame_stamp;
    }
    *r=vertex_side[v];*z=vertex_depth[v];
}

static int project(int height,int z) { return CENTER-(int)((int32_t)(height-player.eye)*FOCAL/z); }
static const uint8_t *lighting(unsigned sector,int z) {
    int shade=(255-map_sectors[sector].light)/8+z/128;
    return colormaps+CLAMP(shade,0,31)*256;
}

static void plane_column(int x,int y1,int y2,uint8_t plane) {
    for (int y=y1;y<=y2;++y) planes[y*VIEW_W+x]=plane;
}

static void wall_column(int x,int y1,int y2,int tex,int u,int top,int z,int yoff,const uint8_t *light) {
    if (y1>y2 || tex==255) return;
    ++render_stats.wall_columns;
    int shiftx=(int)tile_info[tex][1]-5,shifty=(int)tile_info[tex][2]-5;
    const uint8_t *image=images[tex];
    unsigned tx=(shiftx>=0?((unsigned)u>>shiftx):((unsigned)u<<-shiftx))&31;
    int step=z*256/FOCAL;
    int v=(top-player.eye+yoff)*256+(y1-CENTER)*step;
    /* Convert to texture coordinates once per column. Keep pixel-loop
     * arithmetic in the eZ80's native 24-bit int, without 32-bit helpers. */
    if (shifty>=0) {v>>=shifty;step>>=shifty;}
    else {v*=1<<-shifty;step*=1<<-shifty;}
    uint8_t depth=(uint8_t)CLAMP(z/16,1,254);
    unsigned offset=y1*VIEW_W+x;
    for (int y=y1;y<=y2;++y,offset+=VIEW_W,v+=step) {
        unsigned ty=((unsigned)v>>8)&31;
        framebuffer[offset]=light[image[ty*32+tx]];
        depthbuffer[offset]=depth;
    }
}

static void draw_seg(const Seg *seg) {
    const Line *line=&map_lines[seg->line];
    const Side *side=&sides[line->side[seg->side]];
    unsigned fs=side->sector;
    unsigned opposite=line->side[seg->side^1];
    int bs=opposite==65535u?-1:sides[opposite].sector;
    int r1,z1,r2,z2;
    vertex(seg->v1,&r1,&z1);vertex(seg->v2,&r2,&z2);
    /* Backface cull before clipping, using the projected segment winding. */
    if ((int32_t)r1*z2>=(int32_t)r2*z1 || (z1<NEAR_Z && z2<NEAR_Z)) return;
    int u1=side->x+seg->offset,u2=u1+seg->length;
    if (z1<NEAR_Z) {
        r1+=(int)((int32_t)(r2-r1)*(NEAR_Z-z1)/(z2-z1));
        u1+=(int)((int32_t)(u2-u1)*(NEAR_Z-z1)/(z2-z1));z1=NEAR_Z;
    }
    if (z2<NEAR_Z) {
        r2+=(int)((int32_t)(r1-r2)*(NEAR_Z-z2)/(z1-z2));
        u2+=(int)((int32_t)(u1-u2)*(NEAR_Z-z2)/(z1-z2));z2=NEAR_Z;
    }
    int sx1=64+(int)((int32_t)r1*FOCAL/z1),sx2=64+(int)((int32_t)r2*FOCAL/z2);
    if (sx1>=sx2 || sx2<=0 || sx1>=VIEW_W) return;
    int start=MAX(0,sx1),end=MIN(VIEW_W,sx2);
    int32_t iz1=262144L/z1,iz2=262144L/z2;
    int32_t uz1=(int32_t)u1*iz1,uz2=(int32_t)u2*iz2;
    int span=sx2-sx1;
    int32_t diz=(iz2-iz1)/span,duz=(uz2-uz1)/span;
    int32_t iz=iz1+diz*(start-sx1),uz=uz1+duz*(start-sx1);
    int fceil=sector_ceiling[fs],ffloor=sector_floor[fs];
    bool skyportal=bs>=0 && map_sectors[fs].ceiltex==255 && map_sectors[bs].ceiltex==255;
    if (skyportal) fceil=sector_ceiling[bs];
    bool solid=bs<0 || sector_ceiling[bs]<=ffloor || sector_floor[bs]>=fceil || sector_ceiling[bs]<=sector_floor[bs];
    ++render_stats.segs;
    for (int x=start;x<end;++x,iz+=diz,uz+=duz) {
        int top=cliptop[x],bottom=clipbottom[x];
        if (top>=bottom || iz<=0) continue;
        int z=(int)(262144L/iz),u=(int)(uz/iz);
        int cy=project(fceil,z),fy=project(ffloor,z);
        plane_column(x,top,MIN(bottom-1,cy-1),(uint8_t)(fs|128));
        plane_column(x,MAX(top,fy),bottom-1,(uint8_t)fs);
        const uint8_t *light=lighting(fs,z);
        if (solid) {
            int texture=side->middle;
            if (texture==255 && bs>=0) texture=side->upper;
            if (texture==255 && bs>=0) texture=side->lower;
            int anchor=fceil;
            if (texture!=255 && (line->flags&16)) anchor=ffloor+(1<<tile_info[texture][2]);
            wall_column(x,MAX(top,cy),MIN(bottom-1,fy-1),texture,u,anchor,z,side->y,light);
            cliptop[x]=clipbottom[x];
        } else {
            int bceil=sector_ceiling[bs],bfloor=sector_floor[bs];
            int upper=project(bceil,z),lower=project(bfloor,z);
            if (bceil<fceil && !skyportal) {
                int anchor=(line->flags&8)?fceil:bceil+(side->upper==255?128:(1<<tile_info[side->upper][2]));
                wall_column(x,MAX(top,cy),MIN(bottom-1,upper-1),side->upper,u,anchor,z,side->y,light);
            }
            if (bfloor>ffloor) {
                int anchor=(line->flags&16)?fceil:bfloor;
                wall_column(x,MAX(top,lower),MIN(bottom-1,fy-1),side->lower,u,anchor,z,side->y,light);
            }
            cliptop[x]=(uint8_t)CLAMP(MAX(top,MAX(cy,upper)),top,bottom);
            clipbottom[x]=(uint8_t)CLAMP(MIN(bottom,MIN(fy,lower)),cliptop[x],bottom);
        }
    }
}

static bool bbox_visible(const int16_t *box) {
    /* Doom bbox order: top, bottom, left, right. Conservative near-plane
     * handling avoids dropping geometry when the camera intersects a box. */
    int left=VIEW_W,right=0,behind=0;
    if (camx>=box[2] && camx<=box[3] && camy>=box[1] && camy<=box[0]) return true;
    for (unsigned i=0;i<4;++i) {
        int dx=box[2+(i&1)]-camx,dy=box[(i>>1)&1]-camy;
        int z=(int)(((int32_t)dx*camcos+(int32_t)dy*camsin)/256);
        if (z<NEAR_Z) {++behind;continue;}
        int r=(int)(((int32_t)dx*camsin-(int32_t)dy*camcos)/256);
        int sx=64+(int)((int32_t)r*FOCAL/z);
        left=MIN(left,sx);right=MAX(right,sx);
    }
    if (behind==4) return false;
    if (behind) return true;
    left=MAX(0,left);right=MIN(VIEW_W-1,right);
    for (int x=left;x<=right;++x) if (cliptop[x]<clipbottom[x]) return true;
    return false;
}

static void bsp(unsigned index,unsigned depth) {
    if (depth>render_stats.bsp_depth) render_stats.bsp_depth=(uint8_t)depth;
    if (index&0x8000u) {
        const Subsector *sub=&subsectors[index&0x7fffu];
        ++render_stats.subsectors;
        for (unsigned i=0;i<sub->count;++i) draw_seg(&segs[sub->first+i]);
        return;
    }
    const Node *n=&nodes[index];
    unsigned side=node_side(camx,camy,n);
    bsp(n->child[side],depth+1);
    if (bbox_visible(n->bbox[side^1])) bsp(n->child[side^1],depth+1);
}

static void draw_planes(void) {
    for (int y=0;y<VIEW_H;++y) {
        for (int x=0;x<VIEW_W;) {
            unsigned offset=y*VIEW_W+x;
            uint8_t plane=planes[offset];
            if (plane==255) {++x;continue;}
            int end=x+1;
            while (end<VIEW_W && planes[y*VIEW_W+end]==plane) ++end;
            ++render_stats.plane_spans;
            unsigned sector=plane&127;
            int ceiling=plane&128;
            int texture=ceiling?map_sectors[sector].ceiltex:map_sectors[sector].flat;
            if (texture==255) {
                const uint8_t *sky=images[SKY_TILE];
                for (;x<end;++x,++offset) framebuffer[offset]=sky[(y*24/VIEW_H)*32+(((player.angle>>3)+x/4)&31)];
                continue;
            }
            int height=ceiling?sector_ceiling[sector]:sector_floor[sector];
            int dy=CENTER-y;
            int32_t distance=dy?((int32_t)(height-player.eye)*FOCAL*256/dy):8192L*256;
            distance=CLAMP(distance,1,8192L*256);
            int z=(int)(distance/256);
            const uint8_t *light=lighting(sector,z);
            const uint8_t *image=images[texture];
            if (!player.texture_planes) {
                memset(framebuffer+offset,light[image[16*32+16]],end-x);
                memset(depthbuffer+offset,CLAMP(z/16,1,254),end-x);
                x=end;continue;
            }
            int stepx=(int)(distance*camsin/(FOCAL*256L)),stepy=(int)(-distance*camcos/(FOCAL*256L));
            int wx=(int)(player.x+distance*camcos/256+stepx*(x-64));
            int wy=(int)(player.y+distance*camsin/256+stepy*(x-64));
            uint8_t depth=(uint8_t)CLAMP(z/16,1,254);
            for (;x<end;++x,++offset,wx+=stepx,wy+=stepy) {
                unsigned tx=((unsigned)wx>>9)&31,ty=((unsigned)wy>>9)&31;
                framebuffer[offset]=light[image[ty*32+tx]];
                depthbuffer[offset]=depth;
            }
        }
    }
}

static void draw_sprites(void) {
    unsigned count=0;
    for (unsigned i=0;i<NUM_ACTORS;++i) {
        if (actors[i].removed) continue;
        int dx=actors[i].x-camx,dy=actors[i].y-camy;
        int z=(int)(((int32_t)dx*camcos+(int32_t)dy*camsin)/256);
        int r=(int)(((int32_t)dx*camsin-(int32_t)dy*camcos)/256);
        if (z<8 || ABS(r)>z+64) continue;
        sprite_z[i]=(int16_t)z;sprite_x[i]=(int16_t)r;
        unsigned j=count;
        while (j && sprite_z[sprite_order[j-1]]<z) {sprite_order[j]=sprite_order[j-1];--j;}
        sprite_order[j]=(uint8_t)i;++count;
    }
    for (unsigned k=0;k<count;++k) {
        unsigned i=sprite_order[k];
        const MapActor *m=&map_actors[i];Actor *a=&actors[i];
        int z=sprite_z[i],center=64+(int)((int32_t)sprite_x[i]*FOCAL/z);
        int width=MAX(1,(int)((int32_t)m->width*FOCAL/z));
        int height=MAX(1,(int)((int32_t)m->height*FOCAL/z));
        bool corpse=m->hp && !a->hp;
        if (corpse) height=MAX(1,height/4);
        int left=center-width/2,bottom=project(sector_floor[a->sector],z),top=bottom-height;
        unsigned image=corpse?m->death:((player.ticks&8)?m->walk:m->image);
        const uint8_t *pixels=images[image],*light=lighting(a->sector,z);
        uint8_t depth=(uint8_t)CLAMP(z/16,1,254);
        int x1=MAX(0,left),x2=MIN(VIEW_W,left+width),y1=MAX(0,top),y2=MIN(VIEW_H,bottom);
        unsigned sxstep=(64u*256)/width,systep=(64u*256)/height;
        unsigned sypos=(unsigned)(y1-top)*systep;
        for (int y=y1;y<y2;++y,sypos+=systep) {
            unsigned sy=MIN(63,sypos>>8),sxpos=(unsigned)(x1-left)*sxstep;
            for (int x=x1;x<x2;++x,sxpos+=sxstep) {
                unsigned offset=y*VIEW_W+x;
                if (depth>=depthbuffer[offset]) continue;
                unsigned sx=MIN(63,sxpos>>8);
                uint8_t pixel=pixels[sy*64+sx];
                if (pixel!=255) {framebuffer[offset]=light[pixel];depthbuffer[offset]=depth;}
            }
        }
    }
}

void engine_render(void) {
    memset(&render_stats,0,sizeof(render_stats));
    memset(framebuffer,0,sizeof(framebuffer));
    memset(depthbuffer,255,sizeof(depthbuffer));
    memset(planes,255,sizeof(planes));
    memset(cliptop,0,sizeof(cliptop));
    memset(clipbottom,VIEW_H,sizeof(clipbottom));
    if (!++frame_stamp) {memset(vertex_stamp,0,sizeof(vertex_stamp));++frame_stamp;}
    camx=(int)(player.x/256);camy=(int)(player.y/256);
    camcos=icos(player.angle);camsin=isin(player.angle);
    bsp(NUM_NODES-1,0);
    draw_planes();
    draw_sprites();
    const uint8_t *gun=images[player.fire>=5?FIRE_TILE:GUN_TILE];
    int bob=(isin(player.ticks*16)/128);
    for (int y=0;y<28;++y) {
        int dest=52+y+bob;
        if (dest<0 || dest>=VIEW_H) continue;
        for (int x=0;x<25;++x) {
            uint8_t pixel=gun[(y*64/28)*64+x*64/25];
            if (pixel!=255) framebuffer[dest*VIEW_W+52+x]=pixel;
        }
    }
    /* Subtle crosshair uses palette entry 4 (near-white in Doom PLAYPAL). */
    framebuffer[39*VIEW_W+64]=4;
    framebuffer[41*VIEW_W+64]=4;
    framebuffer[40*VIEW_W+63]=4;
    framebuffer[40*VIEW_W+65]=4;
}
