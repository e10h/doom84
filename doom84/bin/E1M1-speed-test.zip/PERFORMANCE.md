# Performance target remains unmet

The original calculator build was reported at about 2 FPS: roughly 1000 ms
rendering textured floors/ceilings and 600 ms with solid-color planes.
CEmu measured that renderer at 979 ms textured and 683 ms flat at spawn,
which was useful for establishing an optimization baseline.

This speed-test revision keeps the actual E1M1 linedefs, BSP, sectors, doors,
actors and wall textures. It adds assembly sprite spans, shared transformed
and projected BSP corners, cached wall styles, narrower arithmetic, faster
column expansion, cached shade data and pre-scaled pistol images. Fast mode
renders sprites at the same column sampling as walls, so it no longer needs
to expand the wall depth buffer. The compiler uses O3 with frame pointers;
more aggressive builds without frame pointers produced incorrect output
and were rejected.

The default remains **64×80 sampling with flat planes**. TRACE additionally
offers 32×80 sampling. Every mode produces a 128×80 framebuffer, with world
and sprite columns replicated in lower sampling modes; the pistol is drawn
after that expansion. This is a visible quality tradeoff, not native 128-column
rendering.

Isolated renderer results at 48 MHz on CEmu ASIC I:

| Scene | 128×80 flat | 64×80 flat | 32×80 flat | 128×80 textured |
| --- | ---: | ---: | ---: | ---: |
| Spawn | 194.83 ms | 149.70 ms | 123.82 ms | 340.48 ms |
| Courtyard | 214.45 ms | 164.77 ms | 132.06 ms | 429.52 ms |
| Later room | 148.28 ms | 104.02 ms | 78.89 ms | 251.21 ms |
| Spawn, diagonal | 176.58 ms | 132.04 ms | 105.11 ms | 323.93 ms |
| Courtyard, diagonal | 239.71 ms | 187.32 ms | 149.85 ms | 411.21 ms |

The default spawn render is about **4.6× faster than the original emulated
flat-plane baseline**. These results execute the compiled eZ80 code, with map
and images in emulated flash. All 30 emulated frames match native C reference
images byte for byte. Native checks also exercise 3792 sector/direction/detail
frames. Emulation needs no TI ROM.

**These are not whole-game FPS measurements.** They omit TI-OS, LCD DMA,
input, simulation, viewport scaling, HUD drawing and presentation. Most views
still exceed 100 ms for rendering alone. The work therefore does not yet
meet the user's playability request; the transfer ZIP is a test candidate.

The attempted conservative portal visibility precomputation produced missing
geometry in boundary views and was rejected. An alternate exact-linedef grid
traversal produced correct test images but ran slower, so it was also rejected.
Neither prototype is enabled or included in the packaged source.

Reproduce:

```sh
make assets WAD=/path/to/doom1.wad
make
make check-host
python3 tests/check_assets.py /path/to/doom1.wad
python3 tools/cemu_bench.py --cemu /path/to/CEmu
```

The benchmark records its CEmu commit, timing results and limitations in
`build/cemu-benchmark.json`. Native timings are not calculator timings.
