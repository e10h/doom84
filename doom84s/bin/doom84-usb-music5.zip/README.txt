Doom84 USB music update

Transfer all EIGHT included files to Archive:
 D84USB5.8xp
 D84M0.8xv
 D84M1.8xv
 D84M2.8xv
 D84M3.8xv
 D84M4.8xv
 D84M5.8xv
 D84M6.8xv
Keep your existing archived D84UI, D84SFX, D84MAP, D84T0..3 and libraries.
Run D84USB5. You can delete the previous D84USB4 program after transferring.

Quit TI Connect CE. Open http://127.0.0.1:3012/usb in Chrome and connect
Doom84 USB PCM. Reconnect the USB cable if the picker is stale.
Music begins when the USB receiver drains audio. Fire with 2nd; CLEAR exits.

Full 101.19-second E1M1 render loops at 4 kHz, mixed on the calculator
with four simultaneous sampled sound effects. Music uses ready-to-play PCM reads directly from Archive.
The music banks occupy 404,831 bytes in Archive, not RAM.
Expanded program: 64,922 bytes (checked below 64 KiB).
The renderer uses speed optimizations with inlining limited to fit RAM.
ROM-free native mixer timing at 48 MHz: music alone 7.2% CPU,
four simultaneous effects plus music 33.6% CPU. These measure the mixer,
not total game/USB overhead. Previous four-voice ADPCM mixer was 96.2%.
USB events are serviced at most once per millisecond, and the transfer
slot is cached across a packet instead of searched for every sample.
Software tests cover the entire decoded track, bank transitions, looping,
mute, USB cadence/timer wrap, all sound effects and the existing engine.
Hardware music playback and game speed still need verification.
