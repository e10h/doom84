Doom84 USB SFX3 - compact startup test

Transfer all THREE files to Archive:
 D84USB3.8xp
 D84SFX.8xv
 D84UI.8xv
Keep your existing archived D84MAP and D84T0..3 and libraries.
Run D84USB3 (a new name), NOT DOOM84S.

Expanded executable: 58,343 bytes. Stored executable: 33,206 bytes.
HUD, gun and sound samples stay in Archive. Four-voice USB queue is
initialized program storage and does not consume the small C heap.
The executable is compiled for size; hardware startup and FPS unverified.

After the game starts, quit TI Connect CE. Connect Doom84 USB PCM
at http://127.0.0.1:3012/usb in Chrome. Fire with 2nd; CLEAR exits.
If startup still fails, report or photograph the EXACT error wording.
